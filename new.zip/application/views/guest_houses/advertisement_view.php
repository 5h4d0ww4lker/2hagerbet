
<!-- BEGIN STEPS -->

<!-- END STEPS -->

<!-- BEGIN CLIENTS -->
<div class="container">
<div class="row-fluid margin-bottom-40">
    <div class="span3">
        <h2><a href="#">Our Sponsors</a></h2>
        <p>Advertise Your Company Here.</p>
    </div>
    <div class="span9">
        <ul class="bxslider1 clients-list">
            
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" class="color-img" alt="" id="adv" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" class="color-img" alt="" id="adv" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" class="color-img" alt="" id="adv" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" class="color-img" alt="" id="adv" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" class="color-img" alt="" id="adv" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/advertise here.png" class="color-img" alt="" id="adv" />
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- END CLIENTS -->
</div>
<!-- END CONTAINER --></div>