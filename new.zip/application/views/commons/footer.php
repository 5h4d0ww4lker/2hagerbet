<!-- BEGIN FOOTER -->
<div class="front-footer">
    <div class="container">
        <div class="row-fluid">
            <div class="span4 space-mobile">
                <!-- BEGIN ABOUT -->
                <h2>About</h2>
                <p class="margin-bottom-30">GreenWare Team is a team of software Engineers who have a great passion in web developing,system design and other activities.<br/>Most of our accomplishments are Online Lottery Application, Clinic Management System, Bank Queue System and two websites www.2hagerbet.com and www.gw.com.
                    Visit Us On www.greenwareteam.com</p>
                <div class="clearfix"></div>
                <!-- END ABOUT -->


                <!-- END BLOG PHOTOS STREAM -->
            </div>
            <div class="span4 space-mobile">
                <!-- BEGIN CONTACTS -->
                <h2>Contact Us</h2>
                <address class="margin-bottom-40">
                    For Registration Details. <br />
                    Nebil Fikru, CEO +251920469132 <br />

                    For Technical Details <br />
                    Melaku Minas, Engineering Executive +251920930598 <br />
                    Email: <a href="#">he@2hagerbet.com</a>
                    website: <a href="gw.2hagerbet.com">gw.2hagerbet.com</a>
                </address>
                <!-- END CONTACTS -->

                <!-- BEGIN SUBSCRIBE -->

                <!-- END SUBSCRIBE -->
            </div>




<div class="span4 space-mobile">
                <!-- BEGIN CONTACTS -->
                <h2>Services</h2>
                <addressa class="margin-bottom-40">
                     Advertising Hotels, Restaurants, Guest Houses, Clubs, Resorts, Loges and Different Tour and Travel Companies, Professional website Design Starting from 3500 ETB, Database Design, Logo Design, Computer Maintenance <br />
                   For Advertisement and Marketing Details<br/>Yabi Molla, Marketing Executive +251911450088 <br />

                    
                </addressa>
                <!-- END CONTACTS -->

                <!-- BEGIN SUBSCRIBE -->

                <!-- END SUBSCRIBE -->
            </div>













        </div>
    </div>
</div>
<!-- END FOOTER -->



<!-- BEGIN COPYRIGHT -->
<div class="front-copyright">
    <div class="container">
        <div class="row-fluid">
            <div class="span8">
                <p>
                    <span class="margin-right-10">2015 © Greenware Team. ALL Rights Reserved.</span>
                    <a href="#">Privacy Policy</a> | <a href="#">Terms of Service | <a href=<?php echo site_url('hag22673627bet8001niki1base5621ac/register') ?>>Register</a> | <a href=<?php echo site_url('hag22673627bet8001niki1base5621ac/loginer') ?>>Login</a> Web Master: Melaku Minas
                </p>
            </div>
            <div class="span4">
                <ul class="social-footer">
                    <li><a href="#"><i class="icon-facebook"></i></a></li>
                    <li><a href="#"><i class="icon-google-plus"></i></a></li>
                    <li><a href="#"><i class="icon-linkedin"></i></a></li>
                    <li><a href="#"><i class="icon-twitter"></i></a></li>
                    <li><a href="#"><i class="icon-instagram"></i></a></li>
                    

                </ul>
            </div>
        </div>
    </div>
</div>
<!-- END COPYRIGHT -->

<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
<!-- BEGIN CORE PLUGINS -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/back-to-top.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/bxslider/jquery.bxslider.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/hover-dropdown.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/revolution_slider/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/revolution_slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>












<!--[if lt IE 9]>
<script src="<?php echo base_url(); ?>assets/plugins/respond.min.js"></script>
<![endif]-->
<!-- END CORE PLUGINS -->
<script src="<?php echo base_url(); ?>assets/scripts/app.js"></script>
<script src="<?php echo base_url(); ?>assets/scripts/index.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        App.init();
        App.initBxSlider();
        Index.initRevolutionSlider();
    });
</script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>