<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2015 <a href="http://gw.2hagerbet.com">Greenware Team</a>.</strong> All rights reserved.
</footer>