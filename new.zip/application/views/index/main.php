<body class="page-header-fixed page-full-width">
    
    <!-- BEGIN CONTAINER -->   
    <div class="page-container row-fluid">
        <!-- BEGIN EMPTY PAGE SIDEBAR -->
    
        <!-- END EMPTY PAGE SIDEBAR -->
        <!-- BEGIN PAGE -->
        <div class="page-content no-min-height">
            
            <!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
            <!-- BEGIN PAGE CONTAINER-->
            <div class="container-fluid promo-page">
                <!-- BEGIN PAGE CONTENT-->
                <div class="row-fluid">
                    <div class="span12">
                        <div class="block-grey">
                            <div class="container">
                                <div id="promo_carousel" class="carousel slide">
                                    <div class="carousel-inner">
                                        <div class="active item">
                                            <div class="row-fluid">
                                                <div class="span7 margin-bottom-20 margin-top-20 animated rotateInUpRight">
                                                    <h1>Welcome to 2hagerbet..</h1>
                                                    <h5>The best hotel searching website in ethiopia. You can find different hotels, restaurants,guest houses and clubs. You can find what ever you want based on your search parameters. This Includes Hotel,Resort,Guest House Basic Information, Room Prices, Available Services,Room Services, Room Prices, and Also Booking, Contact and Several Services. Additionally Restaurant Basic Information, Restaurant Menu, Restaurant Special,Other facilities, and Also Table Reservation, Contact and Several Services. For Clubs and Cultural Places Basic Information, Restaurant Menu, Available Food and Drink Items, Schedules, Days ,Other facilities, and Also Table Reservation, Contact and Several Services.</h5>


                                                    
                                                    <a href="#" class="btn red big xlarge">
                                                    Take a tour
                                                    <i class="m-icon-big-swapright m-icon-white"></i>                                
                                                    </a>
                                                </div>
                                                <div class="span5 animated rotateInDownLeft">
                                                    <img src="<?php echo base_url(); ?>advert/1.png" alt="" id="homepic"/>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="row-fluid">
                                                <div class="span5 animated rotateInUpRight">
                                                    <img src="<?php echo base_url(); ?>advert/sl.jpg" alt="" width="500" height="200" />
                                                </div>
                                                <div class="span7 margin-bottom-20 animated rotateInDownLeft">
                                                    <h1>Register</h1>
                                                    <h4>You can register your Hotel on our website and create a profile for your Hotel.You can add many informations about your hotel inclluding basic info, room infos, room types, room prices, available food and drink items,available room types other room additional Hotel services and events that comming upon your Hotel.Your customers can see your info in our website and book a room or reserve a table in your Hotel.</h4>
                                                    <a href=<?php echo site_url('hag22673627bet8001niki1base5621ac/register') ?> class="btn green big xlarge">

                                                   Register
                                                    <i class="m-icon-big-swapright m-icon-white"></i>                                
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <a class="carousel-control left" href="#promo_carousel" data-slide="prev">
                                    <i class="m-icon-big-swapleft m-icon-white"></i>
                                    </a>
                                    <a class="carousel-control right" href="#promo_carousel" data-slide="next">
                                    <i class="m-icon-big-swapright m-icon-white"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        </div>

                        <div class="block-transparent">
                            <div class="container">
                                <div class="row-fluid margin-bottom-20">
                                    <div class="span6 margin-bottom-20">
                                        <br/><br/>
                                        <h2>Enjoy</h2>
                                        <p>After a few month of hard working, after collecting, selecting and classifying Directories for our website, choosing the best to show you… we are proud to launch our website. Now, with more catagories! ;-)

Moreover, with this webste, we begin a new phase with our directories, where we will share with you new infos about many accomodaton and tour guide companies .

Take a look and hope you like it.</p>
                                        
                                    </div>
                                    <div class="span6 margin-bottom-20">
                                        <br/><br/>
                                        <iframe src="https://calendar.google.com/calendar/embed?title=Holdays%20In%20Ethiopia&amp;height=270&amp;wkst=1&amp;hl=en&amp;bgcolor=%23ffcc66&amp;src=en.et%23holiday%40group.v.calendar.google.com&amp;color=%23125A12&amp;ctz=Africa%2FKhartoum" style="border:solid 1px #777" width="550" height="270" frameborder="0" scrolling="no"></iframe>
                                    </div>
                                </div>
                                
                                <hr>
                                <h3>Sponsors</h3>
                                <div class="row-fluid">

                                    <div class="span3">
                                        
                                        <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" /></div>
                                    <div class="span3">
                                       
                                       <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />  </div>
                                    <div class="span3">
                                        
                                       <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />   </div>
                                    <div class="span3">
                                       <img src="<?php echo base_url(); ?>advert/advertise here.png" alt="" id="adv" />  </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- END PAGE CONTENT-->
        </div>
        <!-- END PAGE CONTAINER--> 
    </div>