


    <!-- BEGIN CONTAINER -->   
    <div class="container min-hight">
        <!-- BEGIN BLOG -->
        <div class="row-fluid">
            <!-- BEGIN LEFT SIDEBAR -->            
            <div class="span9 blog-posts margin-bottom-40">
                <div class="row-fluid">
                    <div class="span7">
                        <!-- BEGIN CAROUSEL -->            
                       <div class="container" id="search_area">
<div class="margin-bottom-30">
    <h4>Check Availability</h4><br/><br/>
    <form method="post" action="<?php echo base_url('index.php/clubs/check_availablity') ?>">
        <select class="form-control" name="club_city" id="liststr">
            <option id="sel">Select City</option>
            <option id="sel" value="Addis Ababa">Addis Ababa</option>
            <option id="sel" value="Adama">Adama</option>
            <option id="sel" value="Debre zeit">D/Zeit</option>
            <option id="sel" value="diredawa">Diredawa</option>
            <option id="sel" value="bahir dar">Bahir Dar</option>
        </select>&nbsp;&nbsp;&nbsp;&nbsp;

        <select class="form-control" name="club_location" id="liststr">
            <option id="sel"> <label id="lmn">Select Location</label></option>
            <option id="sel">Bole</option>
            <option id="sel">Cazanchis</option>
            <option id="sel">4 Kilo</option>
            <option id="sel">Piassa</option>
            <option id="sel">Asko</option>
            <option id="sel">Sar Bet</option>
            <option id="sel">Saris</option>
            <option id="sel">22 Mazoria</option>
        </select><br/>
        <select class="form-control" name="star_level" id="liststr">
            <option id="sel">Star Level</option>
            <option id="sel" value="five star">5 star</option>
            <option id="sel" value="Adama">4 Star</option>
            <option id="sel" value="Debre zeit">3 Star</option>
            <option id="sel" value="diredawa">2 Star</option>
            <option id="sel" value="bahir dar">1 Star</option>
        </select>&nbsp;&nbsp;&nbsp;&nbsp;

        <select class="form-control" name="room_price" id="liststr">
            <option id="sel">Max  Price</option>
            <option id="sel"> >2000</option>
            <option id="sel">1500</option>
            <option id="sel">1000-1500</option>
            <option id="sel">500-1000</option>
            <option id="sel"><500</option>
        </select>

        <br/>
        <select class="form-control" name="free_room" id="liststr">
            <option id="sel"> No Of Rooms</option>
            <option id="sel">1</option>
            <option id="sel">2</option>
            <option id="sel">3</option>
            <option id="sel">4</option>
            <option id="sel">5</option>

        </select>&nbsp;&nbsp;&nbsp;&nbsp;
        <select class="form-control" name="available_room_types" id="liststr">
            <option id="liststr">Room Type</option>
            <option id="sel">Suit Room</option>
            <option id="sel">Single Room</option>
            <option id="sel">Twin Room</option>
            <option id="sel">Presidential</option>
            <option id="sel">Special</option>
        </select>
        <br/> <br/>
        <button type="submit" class="btn green">Search Now</button>
    </form>
</div>
</div>        
                    </div>
                    <div class="span5">
                        <h2><a href="blog_item.html">Discriptiion</a></h2>
                        <ul class="blog-info">
                            <li><i class="icon-calendar"></i> 3/09/2015</li>
                            
                            <li><i class="icon-tags"></i> 2hagerbet.com</li>
                        </ul>
                        <p>This Rooms availablity searcher helps you to get the appropeiate and desiered accomodation places within your own search parameters. You can use diiferent parameters for searching clubs like star level. city, location, room prices, free available rooms, room type and other. Thanx For choosing 2hagerbet.com</p>
                        
                    </div>
                </div>
                <hr class="blog-post-sep">
               
               
                           
            </div>
            <!-- END LEFT SIDEBAR -->

            <!-- BEGIN RIGHT SIDEBAR -->            
            <div class="span3 blog-sidebar">
                <!-- BEGIN RECENT NEWS -->                            
                <h2>Advertisements</h2>
                <div class="recent-news margin-bottom-10">
                    <div class="row-fluid margin-bottom-10">
                        <div class="span3">
                            <img src="<?php echo base_url(); ?>adv small.JPG" alt="">                        
                        </div>
                        <div class="span9 recent-news-inner">
                            <h3>Advertise Here</a></h3>
                            <p>Advertise Here For Free</p>
                        </div>                        
                    </div>
                    <div class="row-fluid margin-bottom-10">
                        <div class="span3">
                            <img src="<?php echo base_url(); ?>adv small.JPG" alt="">                        
                        </div>
                        <div class="span9 recent-news-inner">
                            <h3><a href="#">Advertise Here</a></h3>
                            <p>Advertise Here For Free</p>
                        </div>                        
                    </div>
                    <div class="row-fluid margin-bottom-10">
                        <div class="span3">
                            <img src="<?php echo base_url(); ?>adv small.JPG" alt="">                        
                        </div>
                        <div class="span9 recent-news-inner">
                            <h3><a href="#">Advertise Here</a></h3>
                            <p>Advertise Here For Free</p>
                        </div>                        
                    </div>
                </div>
                <!-- END RECENT NEWS -->                            


               

            </div>
            <!-- END RIGHT SIDEBAR -->            
        </div>
        <!-- END BEGIN BLOG -->


<!-- BEGIN OUR TEAM -->
        <div class="row-fluid front-team">
            <h3><a>Best Places(Advertise Here)</a> </h3>
            <ul class="thumbnails">
                <li class="span3 space-mobile">
                    <img src="<?php echo base_url(); ?>advertise here.JPG" alt="">
                    <h3>
                        <a>Advertise Here</a> 
                        <small> Be The First To Adverise Here.</small>
                    </h3>
                    <p> Be The First To Adverise Here. There are Limeted Places. Contact Us Today.</p>
                    
                </li>
                <li class="span3 space-mobile">
                    <img src="<?php echo base_url(); ?>advertise here.JPG" alt="">
                    <h3>
                        <a>Advertise Here</a> 
                        <small> Be The First To Adverise Here.</small>
                    </h3>
                    <p> Be The First To Adverise Here. There are Limeted Places. Contact Us Today.</p>
                   
                </li>
                <li class="span3 space-mobile">
                    <img src="<?php echo base_url(); ?>advertise here.JPG" alt="">
                    <h3>
                        <a>Advertise Here</a> 
                        <small> Be The First To Adverise Here.</small>
                    </h3>
                    <p> Be The First To Adverise Here. There are Limeted Places. Contact Us Today.</p>
                   
                </li>
                <li class="span3">
                    <img src="<?php echo base_url(); ?>advertise here.JPG" alt="">
                    <h3>
                        <a>Advertise Here</a> 
                        <small> Be The First To Adverise Here.</small>
                    </h3>
                    <p> Be The First To Adverise Here. There are Limeted Places. Contact Us Today.</p>
                  
                </li>
            </ul>            
        </div>
        <!-- END OUR TEAM -->


    </div>
    <!-- END CONTAINER -->